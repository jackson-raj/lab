@echo off
setlocal enabledelayedexpansion
title FAST Cleanup - Kali Lab
color 0C
pushd "%~dp0"

:: Check for Administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges for FAST cleanup...
    powershell -Command "Start-Process cmd -ArgumentList '/c pushd ""%~dp0"" && ""%~f0""' -Verb RunAs"
    popd
    exit /b
)

echo =====================================================================
echo  FAST CLEANUP: Terminating processes and force-removing files...
echo =====================================================================

:: 1. Instantly kill all related processes
echo [1/4] Terminating VirtualBox and Vagrant processes...
taskkill /F /IM VBoxHeadless.exe /T >nul 2>&1
taskkill /F /IM VirtualBox.exe /T >nul 2>&1
taskkill /F /IM VBoxSVC.exe /T >nul 2>&1
taskkill /F /IM VBoxManage.exe /T >nul 2>&1
taskkill /F /IM vagrant.exe /T >nul 2>&1
taskkill /F /IM ruby.exe /T >nul 2>&1

:: 2. Uninstall Vagrant silently
echo [2/4] Uninstalling Vagrant silently...
winget uninstall --id Hashicorp.Vagrant --silent --accept-source-agreements >nul 2>&1

:: 3. Uninstall VirtualBox silently
echo [3/4] Uninstalling VirtualBox silently...
winget uninstall --id Oracle.VirtualBox --silent --accept-source-agreements >nul 2>&1

:: 4. Force delete all associated files and VMs instantly
echo [4/4] Wiping all project files, VMs, and caches...
:: Delete local project folders
for %%D in (EH_Lab metasploitable kali-vagrant) do (
    if exist "%%D" rd /s /q "%%D"
)
:: Delete Vagrant cache and downloaded boxes
if exist "%USERPROFILE%\.vagrant.d" rd /s /q "%USERPROFILE%\.vagrant.d"
:: Delete VirtualBox VM data
if exist "%USERPROFILE%\VirtualBox VMs" rd /s /q "%USERPROFILE%\VirtualBox VMs"
:: Delete VirtualBox global settings
if exist "%USERPROFILE%\.VirtualBox" rd /s /q "%USERPROFILE%\.VirtualBox"

echo.
echo =====================================================================
echo  DONE! Everything was wiped out instantly.
echo =====================================================================
timeout /t 5
popd
