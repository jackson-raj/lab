# =====================================================
#   KALI LINUX AUTO-INSTALLER (VIRTUALBOX + VAGRANT)
# =====================================================

# Set the working directory to the script's own location
Set-Location -Path $PSScriptRoot

$host.UI.RawUI.WindowTitle = "Kali Linux Auto-Installer"

Write-Host ""
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "   KALI LINUX AUTO-INSTALLER (VirtualBox + Vagrant)  " -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script will automatically install:" -ForegroundColor White
Write-Host "  1. VirtualBox"
Write-Host "  2. Vagrant"
Write-Host "  3. Kali Linux VM with XFCE GUI"
Write-Host ""

# ─── Helper function ────────────────────────────────
function Test-CommandExists {
    param([string]$cmd)
    return [bool](Get-Command $cmd -ErrorAction SilentlyContinue)
}

# ─── STEP 1: Check winget ───────────────────────────
Write-Host "[1/5] Checking for winget (Windows Package Manager)..." -ForegroundColor Yellow
if (-not (Test-CommandExists "winget")) {
    Write-Host "[ERROR] 'winget' is not available on this system." -ForegroundColor Red
    Write-Host "Please install 'App Installer' from the Microsoft Store, or update Windows." -ForegroundColor Red
    Write-Host ""
    Read-Host "Press ENTER to exit"
    exit 1
}
Write-Host "[OK] winget is available." -ForegroundColor Green

# ─── STEP 2: Install VirtualBox ─────────────────────
Write-Host ""
Write-Host "[2/5] Checking for VirtualBox..." -ForegroundColor Yellow

$vboxPaths = @(
    "C:\Program Files\Oracle\VirtualBox\VBoxManage.exe",
    "C:\Program Files\Oracle\VM VirtualBox\VBoxManage.exe"
)
$vboxFound = Test-CommandExists "VBoxManage"
if (-not $vboxFound) {
    foreach ($p in $vboxPaths) {
        if (Test-Path $p) { $vboxFound = $true; break }
    }
}

if ($vboxFound) {
    Write-Host "[OK] VirtualBox is already installed." -ForegroundColor Green
} else {
    Write-Host "[INFO] VirtualBox not found. Downloading and installing..." -ForegroundColor Cyan
    Write-Host "[INFO] You will see a real-time download progress bar below." -ForegroundColor White
    Write-Host ""
    winget install -e --id Oracle.VirtualBox --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "[ERROR] VirtualBox installation failed." -ForegroundColor Red
        Write-Host "Please download it manually from: https://www.virtualbox.org" -ForegroundColor Red
        Read-Host "Press ENTER to exit"
        exit 1
    }
    Write-Host ""
    Write-Host "[SUCCESS] VirtualBox installed successfully!" -ForegroundColor Green
}

# ─── STEP 3: Install Vagrant ─────────────────────────
Write-Host ""
Write-Host "[3/5] Checking for Vagrant..." -ForegroundColor Yellow

$vagrantFound = Test-CommandExists "vagrant"
if ($vagrantFound) {
    Write-Host "[OK] Vagrant is already installed." -ForegroundColor Green
} else {
    Write-Host "[INFO] Vagrant not found. Downloading and installing..." -ForegroundColor Cyan
    Write-Host "[INFO] You will see a real-time download progress bar below." -ForegroundColor White
    Write-Host ""
    winget install -e --id Hashicorp.Vagrant --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "[ERROR] Vagrant installation failed." -ForegroundColor Red
        Write-Host "Please download it manually from: https://developer.hashicorp.com/vagrant/downloads" -ForegroundColor Red
        Read-Host "Press ENTER to exit"
        exit 1
    }
    Write-Host ""
    Write-Host "[SUCCESS] Vagrant installed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host " IMPORTANT: Vagrant was just installed for the first time." -ForegroundColor Yellow
    Write-Host " The system PATH has changed. You MUST close this window" -ForegroundColor Yellow
    Write-Host " and run setup_kali.bat AGAIN to continue." -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "Press ENTER to exit. Then run the .bat file again."
    exit 0
}

# ─── STEP 4: Create project folder and Vagrantfile ───
Write-Host ""
Write-Host "[4/5] Setting up Kali Linux project folder..." -ForegroundColor Yellow

$vagrantDir = Join-Path $PSScriptRoot "kali-vagrant"
if (-not (Test-Path $vagrantDir)) {
    New-Item -ItemType Directory -Path $vagrantDir | Out-Null
    Write-Host "[OK] Created folder: $vagrantDir" -ForegroundColor Green
} else {
    Write-Host "[OK] Folder already exists: $vagrantDir" -ForegroundColor Green
}

$vagrantFile = Join-Path $vagrantDir "Vagrantfile"
Write-Host "[INFO] Writing Vagrantfile..." -ForegroundColor Cyan

$vagrantContent = @'
Vagrant.configure("2") do |config|
  config.vm.box = "kalilinux/rolling"
  config.vm.box_check_update = false

  config.vm.provider "virtualbox" do |vb|
    vb.name = "Kali-Linux"
    vb.gui = true
    vb.memory = "4096"
    vb.cpus = 2
  end

  # Automatically install XFCE Desktop GUI on first boot
  config.vm.provision "shell", inline: <<-SHELL
    echo "[INFO] Updating Kali package lists..."
    sudo apt-get update -y
    echo "[INFO] Installing XFCE Desktop (this takes 10-20 mins)..."
    sudo DEBIAN_FRONTEND=noninteractive apt-get install -y kali-desktop-xfce xorg
    echo "[SUCCESS] Desktop installation complete!"
    echo "[INFO] Login: Username=vagrant  Password=vagrant"
  SHELL
end
'@

Set-Content -Path $vagrantFile -Value $vagrantContent -Encoding UTF8
Write-Host "[OK] Vagrantfile created." -ForegroundColor Green

# ─── STEP 5: Start the VM ───────────────────────────
Write-Host ""
Write-Host "[5/5] Starting Kali Linux VM..." -ForegroundColor Yellow
Write-Host ""
Write-Host "======================================================" -ForegroundColor White
Write-Host " NOTE: The Kali Linux image (~1 GB) will be downloaded." -ForegroundColor White
Write-Host " After download, the XFCE GUI will be installed inside." -ForegroundColor White
Write-Host " Total time: 15-45 minutes. DO NOT close this window." -ForegroundColor White
Write-Host "======================================================" -ForegroundColor White
Write-Host ""

Set-Location -Path $vagrantDir
vagrant up

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "======================================================" -ForegroundColor Red
    Write-Host " [ERROR] 'vagrant up' failed." -ForegroundColor Red
    Write-Host " Common Fixes:" -ForegroundColor Red
    Write-Host "   1. RESTART your computer (required after new installs)." -ForegroundColor Red
    Write-Host "   2. Enable Virtualization (VT-x/AMD-V) in your BIOS." -ForegroundColor Red
    Write-Host "   3. Disable Hyper-V: Run as Admin -> 'bcdedit /set hypervisorlaunchtype off' then restart." -ForegroundColor Red
    Write-Host "======================================================" -ForegroundColor Red
} else {
    Write-Host ""
    Write-Host "======================================================" -ForegroundColor Green
    Write-Host " [SUCCESS] Kali Linux is now running!" -ForegroundColor Green
    Write-Host " - A VirtualBox window should be open with the Kali desktop." -ForegroundColor Green
    Write-Host " - Login: vagrant / vagrant" -ForegroundColor Green
    Write-Host " - To open terminal: cd kali-vagrant, then: vagrant ssh" -ForegroundColor Green
    Write-Host "======================================================" -ForegroundColor Green
}

Write-Host ""
Read-Host "Press ENTER to exit"
