(echo hello <<-SHELL)  
