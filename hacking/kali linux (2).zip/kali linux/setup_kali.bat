@echo off
setlocal enabledelayedexpansion
title Kali + Metasploitable Lab Setup
color 0A
pushd "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/k pushd ""%~dp0"" && ""%~f0""' -Verb RunAs"
    popd
    exit /b
)

echo.
echo =====================================================================
echo  Ex No 1: Kali Linux + Metasploitable Lab Setup
echo =====================================================================
echo  [1] Kali Linux      (Attacker)   IP: 192.168.56.100
echo  [2] Metasploitable  (Target)     IP: 192.168.56.110
echo =====================================================================
echo.

:: ─────────────────────────────────────────────────────
:: STEP 1: VirtualBox - auto install if missing
:: ─────────────────────────────────────────────────────
echo [STEP 1] Checking VirtualBox...
set VBOX=0
where VBoxManage >nul 2>&1
if %errorlevel% equ 0 set VBOX=1
if exist "C:\Program Files\Oracle\VirtualBox\VBoxManage.exe" set VBOX=1
if exist "C:\Program Files\Oracle\VM VirtualBox\VBoxManage.exe" set VBOX=1

if %VBOX% equ 1 echo [OK] VirtualBox found.

if %VBOX% equ 0 (
    echo [MISSING] Installing VirtualBox...
    winget install -e --id Oracle.VirtualBox --accept-package-agreements --accept-source-agreements
    if !errorlevel! neq 0 if !errorlevel! neq 3010 if !errorlevel! neq 1641 (
        echo [ERROR] Failed. Download: https://www.virtualbox.org
        pause & popd & exit /b 1
    )
    echo [SUCCESS] VirtualBox installed.
)

:: ─────────────────────────────────────────────────────
:: STEP 2: Vagrant - auto install if missing
:: ─────────────────────────────────────────────────────
echo.
echo [STEP 2] Checking Vagrant...
set VGRANT=0
where vagrant >nul 2>&1
if %errorlevel% equ 0 set VGRANT=1

if %VGRANT% equ 1 echo [OK] Vagrant found.

if %VGRANT% equ 0 (
    echo [MISSING] Installing Vagrant...
    winget install -e --id Hashicorp.Vagrant --accept-package-agreements --accept-source-agreements
    if !errorlevel! neq 0 if !errorlevel! neq 3010 if !errorlevel! neq 1641 (
        echo [ERROR] Failed. Download: https://developer.hashicorp.com/vagrant/downloads
        pause & popd & exit /b 1
    )
    echo [SUCCESS] Vagrant installed.
    echo.
    echo [!] CLOSE this window and run setup_kali.bat AGAIN to continue.
    pause & popd & exit /b 0
)

:: ─────────────────────────────────────────────────────
:: STEP 3: Kali Linux VM
:: Always write Vagrantfile, then vagrant up handles both
:: new install and starting existing VM automatically
:: ─────────────────────────────────────────────────────
echo.
echo =====================================================================
echo  [STEP 3] Kali Linux VM
echo =====================================================================
echo.

if not exist "EH_Lab" mkdir "EH_Lab"
cd "EH_Lab"

echo [INFO] Writing Kali Vagrantfile...
echo Vagrant.configure("2") do ^|config^| > Vagrantfile
echo   config.vm.box = "kalilinux/rolling" >> Vagrantfile
echo   config.vm.box_check_update = false >> Vagrantfile
echo   config.vm.network "private_network", ip: "192.168.56.100" >> Vagrantfile
echo   config.vm.provider "virtualbox" do ^|vb^| >> Vagrantfile
echo     vb.name = "Kali-Linux" >> Vagrantfile
echo     vb.gui = true >> Vagrantfile
echo     vb.memory = "4096" >> Vagrantfile
echo     vb.cpus = 2 >> Vagrantfile
echo   end >> Vagrantfile
echo   config.vm.provision "shell", inline: "sudo apt-get update -y" >> Vagrantfile
echo end >> Vagrantfile
echo [OK] Vagrantfile ready.
echo.
echo [INFO] Running vagrant up for Kali Linux...
echo [INFO] - If VM exists: it will just start it
echo [INFO] - If VM missing: it will download (~1 GB) and create it
echo [INFO] DO NOT close this window.
echo.

vagrant up
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Kali Linux VM failed.
    echo   Fix 1: Restart PC, run this script again.
    echo   Fix 2: Enable VT-x/AMD-V in BIOS.
    echo   Fix 3: Disable Hyper-V: run as Admin: bcdedit /set hypervisorlaunchtype off, restart.
    pause & cd .. & popd & exit /b 1
)
echo.
echo [SUCCESS] Kali Linux is running! Open VirtualBox to see it.

cd ..

:: ─────────────────────────────────────────────────────
:: STEP 4: Metasploitable VM
:: Same approach: always write Vagrantfile first
:: ─────────────────────────────────────────────────────
echo.
echo =====================================================================
echo  [STEP 4] Metasploitable VM
echo =====================================================================
echo.

if not exist "metasploitable" mkdir "metasploitable"
cd "metasploitable"

echo [INFO] Writing Metasploitable Vagrantfile...
echo Vagrant.configure("2") do ^|config^| > Vagrantfile
echo   config.vm.box = "rapid7/metasploitable3-ub1404" >> Vagrantfile
echo   config.vm.box_check_update = false >> Vagrantfile
echo   config.vm.network "private_network", ip: "192.168.56.110" >> Vagrantfile
echo   config.vm.provider "virtualbox" do ^|vb^| >> Vagrantfile
echo     vb.name = "Metasploitable" >> Vagrantfile
echo     vb.gui = false >> Vagrantfile
echo     vb.memory = "2048" >> Vagrantfile
echo     vb.cpus = 2 >> Vagrantfile
echo   end >> Vagrantfile
echo end >> Vagrantfile
echo [OK] Vagrantfile ready.
echo.
echo [INFO] Running vagrant up for Metasploitable...
echo [INFO] - If VM exists: it will just start it
echo [INFO] - If VM missing: it will download (~2 GB) and create it
echo [INFO] DO NOT close this window.
echo.

vagrant up
if %errorlevel% neq 0 (
    echo [WARNING] Metasploitable failed to start.
    echo [INFO] Try manually: cd EH_Lab\metasploitable then vagrant up
) else (
    echo [SUCCESS] Metasploitable is running!
)

cd ..\..

:: ─────────────────────────────────────────────────────
:: DONE
:: ─────────────────────────────────────────────────────
echo.
echo =====================================================================
echo  SETUP COMPLETE - Open Oracle VirtualBox Manager to see both VMs!
echo =====================================================================
echo  Kali-Linux       IP: 192.168.56.100   Login: vagrant/vagrant
echo  Metasploitable   IP: 192.168.56.110   Login: vagrant/vagrant
echo.
echo  [STEP 7] Verify network - in Kali terminal run:
echo    ping 192.168.56.110
echo  Ping replies = Lab setup SUCCESSFUL!
echo =====================================================================
echo.
pause
popd
