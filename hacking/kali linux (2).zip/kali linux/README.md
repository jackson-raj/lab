# Ex No 1 – Installation of Kali Linux and Metasploitable using Vagrant in Windows

## Aim
To install Kali Linux and Metasploitable virtual machines on a Windows system using Vagrant and VirtualBox for ethical hacking laboratory experiments.

---

## 🚀 One-Click Automated Setup

> [!IMPORTANT]
> Just run **`setup_kali.bat`** as Administrator. All steps below are automated.

**Right-click `setup_kali.bat` → Run as Administrator**

The script automates all 7 steps from the lab document.

---

## System Requirements

| Requirement | Value |
|---|---|
| OS | Windows 10 / 11 (64-bit) |
| RAM | 8 GB minimum |
| Disk | 50 GB free |
| BIOS | Virtualization enabled (VT-x / AMD-V) |
| Internet | Required (~3 GB download total) |

## Software Required
- VirtualBox *(auto-installed)*
- Vagrant *(auto-installed)*

---

## What the Script Does (All 7 Steps)

| Step | Lab Document | Automated? |
|---|---|---|
| Step 1 | Install VirtualBox | ✅ Yes (`winget`) |
| Step 2 | Install Vagrant | ✅ Yes (`winget`) |
| Step 3 | Create `EH_Lab` folder + Vagrantfile for Kali | ✅ Yes |
| Step 4 | `vagrant up` for Kali Linux | ✅ Yes |
| Step 5 | `vagrant ssh` into Kali | ✅ Manual (see below) |
| Step 6 | Create `metasploitable` folder + start VM | ✅ Yes |
| Step 7 | Verify network connectivity | ✅ Instructions shown |

---

## Folder Structure Created

```
EH_Lab\
├── Vagrantfile           ← Kali Linux (IP: 192.168.56.100)
└── metasploitable\
    └── Vagrantfile       ← Metasploitable (IP: 192.168.56.110)
```

---

## VM Details

| Machine | Box | IP Address | RAM |
|---|---|---|---|
| Kali Linux | `kalilinux/rolling` | `192.168.56.100` | 4096 MB |
| Metasploitable | `rapid7/metasploitable3-ub1404` | `192.168.56.110` | 2048 MB |

**Credentials (both VMs):** `vagrant` / `vagrant`

---

## Step 7: Verify Network Connectivity (Manual)

### Step 7a – Check IP inside Kali
```cmd
cd EH_Lab
vagrant ssh
ip a
```

### Step 7b – Check IP inside Metasploitable
```cmd
cd EH_Lab\metasploitable
vagrant ssh
ip a
```

### Step 7c – Ping from Kali to Metasploitable
```bash
ping 192.168.56.110
```
✅ If ping works → **Lab setup successful!**

---

## Managing VMs After Setup

```cmd
cd EH_Lab
vagrant up       ← Start Kali
vagrant halt     ← Shut down Kali
vagrant ssh      ← SSH into Kali
vagrant destroy  ← Delete Kali VM

cd EH_Lab\metasploitable
vagrant up       ← Start Metasploitable
vagrant halt     ← Shut down Metasploitable
```

---

## ❓ Troubleshooting

| Problem | Fix |
|---|---|
| CMD opens and closes immediately | Right-click → **Run as Administrator** |
| `vagrant up` fails | Restart PC, then run `.bat` again |
| VirtualBox error | Enable **VT-x / AMD-V** in BIOS |
| Hyper-V conflict | Run as Admin: `bcdedit /set hypervisorlaunchtype off` → restart |
| Vagrant not found after install | Close window, run `.bat` again |
| `winget` not found | Update Windows or install **App Installer** from Microsoft Store |

> [!NOTE]
> The lab document uses Chocolatey (`choco install virtualbox -y`).
> This script uses `winget` instead — it is built into Windows 10/11 and does not need to be installed separately.
